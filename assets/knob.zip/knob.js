export function initKnob(containerSelector) {
  const knobContainer = document.querySelector(containerSelector);
  const handle = knobContainer.querySelector('#handle');
  const angleDisplay = knobContainer.querySelector('#angleDisplay');

  let isDragging = false;
  let currentAngle = 0;

  knobContainer.addEventListener('mousedown', (e) => {
    isDragging = true;
    updateAngle(e);
  });

  document.addEventListener('mousemove', (e) => {
    if (isDragging) updateAngle(e);
  });

  document.addEventListener('mouseup', () => {
    isDragging = false;
  });

  function updateAngle(e) {
    const rect = knobContainer.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = e.clientX - centerX;
    const dy = e.clientY - centerY;
    let angle = Math.atan2(dy, dx) * (180 / Math.PI);
    angle = (angle + 90 + 360) % 360;
    currentAngle = angle;
    handle.style.transform = `translateX(-50%) rotate(${angle}deg)`;
    angleDisplay.textContent = `${angle.toFixed(1)}°`;
  }
}
